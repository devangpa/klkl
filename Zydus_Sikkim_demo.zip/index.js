var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);

io.on('connection', (socket) => {
  console.log('Socket Connection Established with ID :' + socket.id);
  setInterval(() => {
    const kl = Math.floor(Math.random() * 6) + 1;
    console.log(kl);
    socket.emit('news', [
      {January: kl},
      {February: 40},
      {March: 15},
      {April: 73},
      {May: 70},
    ]);
  }, 3000);

  socket.on('my other event', (data) => {
    console.log(data);
  });
});
io.on('connection', (socket) => {
  console.log('Socket Connection Established with ID :' + socket.id);
  setInterval(() => {
    const kl = Math.floor(Math.random() * 500) + 120;
    console.log(kl);
    socket.emit('RandomData', kl);
  }, 20000);

  socket.on('my other event', (data) => {
    console.log(data);
  });
});

http.listen(3000, () => {
  console.log('Socket Data Strated On Port 3000!');
});

app.get('/machine_1', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

const Port = 5000;
app.listen(Port, () => {
  console.log('Application strat on port 5000');
});
