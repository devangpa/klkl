import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
import time,json
import logging
import argparse
import datetime
from pymodbus.client.sync import ModbusTcpClient


def on_log(client, userdata, level, buf):
   print(buf) 
def on_connect(client, userdata, flags, rc):
    if rc==0:
        client.connected_flag=True #set flag
        print("connected OK")
    else:
        print("Bad connection Returned code=",rc)
        client.loop_stop()  
def on_disconnect(client, userdata, rc):
   print("client disconnected")
   client.connect(broker,port)
   time.sleep(1)
def on_publish(client, userdata, mid):
    print("In on_pub callback mid= "  ,mid)
count=0
mqtt.Client.connected_flag=False#create flag in class
mqtt.Client.suppress_puback_flag=False
client = mqtt.Client("python1")             #create new instance 
#client.on_log=on_log
client.on_connect = on_connect
client.on_disconnect = on_disconnect
client.on_publish = on_publish

def ReadData(register, numofreg,id):
	client = ModbusTcpClient('192.168.5.252')
	connection = client.connect()
	value = client.read_holding_registers(register, numofreg, unit=id)
	d = (value.registers)
	Temp = d.pop(0)
	Hum = d.pop(0)
	print(d)
	print(Temp)
	print(Hum)
	return Temp

broker="192.168.3.124"
port =1885
topic="test"
#need to edit user name 
#username="Apx1r8fNNQbr9JILm3" #device house
username=""
password=""
if username !="":
   pass
client.username_pw_set(username, password)
client.connect(broker,port)           #establish connection
while not client.connected_flag: #wait in loop
   client.loop()
   time.sleep(1)
time.sleep(3)
data=dict()



while True:
        message = {}
        message['Data'] = ReadData(170, 2, 1)
        data_out=json.dumps(message) #create JSON object
        print("publish topic",topic, "data out= ",data_out)
        ret=client.publish(topic,data_out,0)    #publish
        #try:
            
            #data_out=json.dumps(message) #create JSON object
            #print("publish topic",topic, "data out= ",data_out)
            #ret=client.publish(topic,data_out,0)    #publish
            
        #except:
            #pass   
        time.sleep(5)